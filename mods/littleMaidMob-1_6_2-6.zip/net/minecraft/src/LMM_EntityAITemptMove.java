package net.minecraft.src;

public class LMM_EntityAITemptMove extends EntityAIBase {

	@Override
	public boolean shouldExecute() {
		// TODO Auto-generated method stub
		return false;
	}

}
